import modules

#Запускає додаток
# API (Application Programming Interface) - Допомагає взаємодіяти двом програмам ( передає дані )
if __name__ == "__main__":
    modules.app.mainloop()
    